import numpy as np

class ANN():
    def __init__(self, lr = 0.01, max_iter = 1000, h = 128):
        self.lr = lr
        self.max_iter = max_iter
        self.h = h

        self.error_array = []
        self.acc_array = []
        self.test_acc_array = []
        self.acc_nC = []
        self.acc_nC_test = []

    def fit(self, X, Y, X_test, Y_test):
        # m = the number of input data
        # n[i] = the number of nodes in ith layer
        #dim(X) = (n[1],m)
        #dim(Y) = (n[2],3)
        #dim(Y_hat) = (n[2],3)
        self.X = X
        self.Y = Y
        self.X_test = X_test
        self.Y_test = Y_test

        self.w1 = np.random.randn(self.h, X.shape[0]) * 0.01
        self.b1 = np.zeros((self.h, 1))
        self.w2 = np.random.randn(Y.shape[0], self.h) * 0.01
        self.b2 = np.zeros((Y.shape[0], 1))

        for i in range(self.max_iter):
            Flag = self.train(i)
            if Flag == True:
                self.cacl_nC_acc(self.X, self.Y, test = False)
                self.cacl_nC_acc(self.X_test, self.Y_test, test = True)
                break
        return 0

    def cacl_nC_acc(self,X, Y, test = False):
        Y_pred = self.predict(X, onehot=True)
        all_class = np.unique(Y, axis = 1)
        for k in all_class:
            acc_arrs = []
            for i in range(Y.shape[1]):
                if (Y.T[i] == k).all():
                    if (Y.T[i] == Y_pred.T[i]).all():
                        acc_arrs.append(1)
                    else:
                        acc_arrs.append(0)
            if test == False:
                self.acc_nC.append(np.mean(acc_arrs))
            else:
                self.acc_nC_test.append(np.mean(acc_arrs))
        return 0

    def ReLU(self, Z):
        return np.maximum(0, Z)

    def Diff_ReLU(self, Z):
        return (np.abs(Z) + Z) / (2*Z)

    def SoftMax(self, Y_hat_raw):
        Y_hat = []
        t = np.exp( Y_hat_raw )
        for k in t.T:
            sum_k = np.sum(k)
            y_hat = [i/sum_k for i in k]
            Y_hat.append(y_hat)
        Y_hat = np.array(Y_hat).T
        return Y_hat
    
    def ForwardP(self, w1, b1, w2, b2, X):
        Z1 = np.dot(w1, X) + b1
        A1 = self.ReLU(Z1)
        Z2 = np.dot(w2, A1) + b2
        A2 = self.SoftMax(Z2)
        return Z1, A1, Z2, A2
    
    #general gradient descent
    def BackP(self, Z1, A1, Z2, A2):
        dZ2 = A2 - self.Y 
        dw2 = np.dot(dZ2, A1.T) / self.Y.shape[1]
        db2 = np.mean(dZ2, axis=1, keepdims=True)
        dZ1 = np.dot(self.w2.T, dZ2) * self.Diff_ReLU(Z1)
        dw1 = np.dot(dZ1, self.X.T) / self.Y.shape[1]
        db1 = np.mean(dZ1, axis=1, keepdims=True)
        return dw1, db1, dw2, db2

    #stochastic gradient descent   
    def BackPSGD(self, z1, a1, z2, a2, k):
        dz2 = a2 - self.Y[:,k]
        dz2 = np.expand_dims(dz2,1)
        a1 = np.expand_dims(a1,1)
        dw2 = np.dot(dz2, a1.T)
        db2 = dz2
        Diffz1 = np.expand_dims(self.Diff_ReLU(z1),1)
        dz1 = np.dot(self.w2.T, dz2) * Diffz1
        Xk = np.expand_dims( self.X[:,k], 1)
        dw1 = np.dot(dz1, Xk.T)
        db1 = dz1
        return dw1, db1, dw2, db2

    def predict(self, X, onehot = True):
        A2_pred = self.ForwardP(self.w1, self.b1, self.w2, self.b2, X)[-1]
        if onehot == False:
            return A2_pred
        return self.VoteSoft(A2_pred)

    def calc_acc(self, y_pred, y_true):
        return np.mean([1 if (y_true[i] == y_pred[i]).all() else 0 for i in range(len(y_pred))])
    
    def VoteSoft(self, Y):
        digits = np.argmax(Y, axis=0)
        bina = []
        for i in digits:
            if i == 0:
                bina.append([1, 0, 0])
            elif i == 1:
                bina.append([0, 1, 0])
            else:
                bina.append([0, 0, 1])
        return np.array(bina).T

    def calc_error(self, Y_pred, Y_true):
        Loss = - Y_true * np.log(Y_pred)
        return  np.sum(Loss) / Y_true.shape[1]

    def train(self,m):
        # k = int( k / self.Y.shape[1] )
        for k in range(self.Y.shape[1]):
            Z1, A1, Z2, A2 = self.ForwardP(self.w1, self.b1, self.w2, self.b2, self.X)
            dw1, db1, dw2, db2 = self.BackPSGD(Z1[:,k], A1[:,k], Z2[:,k], A2[:,k], k)
            self.w1 -= self.lr * dw1
            self.b1 -= self.lr * db1
            self.w2 -= self.lr * dw2
            self.b2 -= self.lr * db2
            Y_pred = self.VoteSoft(A2)
            acc = self.calc_acc(Y_pred.T, self.Y.T)
            loss = self.calc_error(A2, self.Y)
            kth = k+m*self.Y.shape[1]+1
            print("The runing iteration: ", kth , " The error is: ", loss, "The accrancy is: %", acc*100)
            self.error_array.append(loss)
            self.acc_array.append(acc*100)

            ## save the accracys in testing data
            Y_test_pred = self.predict(self.X_test, onehot=True)
            acc_test = self.calc_acc(Y_test_pred.T, self.Y_test.T)
            self.test_acc_array.append(acc_test*100)
            print("The testing accracy is: %", acc_test*100)
            if kth == self.max_iter:
                return True

    ### train using general gradient descent
    # def train(self):
    #     Z1, A1, Z2, A2 = self.ForwardP(self.w1, self.b1, self.w2, self.b2, self.X)
    #     Y_pred = self.VoteSoft(A2)
    #     acc = self.calc_acc(Y_pred.T, self.Y.T)
    #     loss = self.calc_error(A2, self.Y)
    #     dw1, db1, dw2, db2 = self.BackP(Z1, A1, Z2, A2)
    #     self.w1 -= self.lr * dw1
    #     self.b1 -= self.lr * db1
    #     self.w2 -= self.lr * dw2
    #     self.b2 -= self.lr * db2
    #     return acc, loss



        

    

        


        






        
