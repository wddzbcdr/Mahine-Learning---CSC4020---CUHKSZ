import ANN as ann
import data
import numpy as np
import matplotlib.pyplot as plt

train_X, train_y = data.train_X, data.train_y
test_X, test_y = data.test_X, data.test_y

##here you can chage your pramameters
##E.g. if you wanna set learning rate = 0.01, 
##                       max iterations = 500, 
##                       number of nodes in hidden layer = 64
## You just need to set 
##                  model = ann.ANN(lr = 0.01, max_iter = 500, h = 64)
## If you do not input any parameters, 
##                  it will be defaluted (lr = 0.01, max_iter = 1000, h = 128)
model = ann.ANN(h=2048)

# In general the fit function just need to input training set
# However, in our homework we need to plot testing acc curve
# Hence, I add two parameters test_X and test_Y to make it easier to plot the curve
model.fit(train_X, train_y, test_X, test_y)

print("The three classes accracy in training set is: ", model.acc_nC)
print("The three classes accracy in testing set is: ", model.acc_nC_test)

### Plot error and accracy curve in training set
pltX = [i for i in range(model.max_iter)]
pltEY = model.error_array
pltAY = model.acc_array
plt.title("Training Set Error Curve")
plt.xlabel("The kth iterations")
plt.ylabel("Error")
plt.plot(pltX, pltEY)
plt.show()

plt.title("Training Set Accracy Curve")
plt.xlabel("The kth iterations")
plt.ylabel("Accuracy (%)")
plt.plot(pltX, pltAY)
plt.show()

### Plot accracy curve in testing set
pltTAY = model.test_acc_array
plt.title("Testing Set Accracy Curve")
plt.xlabel("The kth iterations")
plt.ylabel("Accuracy (%)")
plt.plot(pltX, pltTAY)
plt.show()
