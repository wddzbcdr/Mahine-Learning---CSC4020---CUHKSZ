import numpy as np

#you should change your path for your computer
tr = open('/Users/zong/Desktop/Class/大四Term2/CSC4020/Assignments/Assignment2/train1.txt','r')
te = open('/Users/zong/Desktop/Class/大四Term2/CSC4020/Assignments/Assignment2/test1.txt','r')

train = tr.readlines()
test = te.readlines()

def seperate_data(train):
    trainX = []
    trainy = []
    for i in range(len(train)):
        if i > 2:
            trX = train[i].strip().split()
            each_x = []
            each_y = []
            for j in range(len(trX)):
                if j < len(trX) - 3:
                    each_x.append(float(trX[j]))
                elif j >= len(trX) - 3:
                    each_y.append(trX[j])
            trainX.append(each_x)
            trainy.append(each_y)
    train_y_1 = []
    for k in trainy:
        num = ''.join(k)
        if num == '001':
            train_y_1.append([0,0,1])
        elif num == '010':
            train_y_1.append([0,1,0])
        else:
            train_y_1.append([1,0,0])
    train_y = train_y_1

    return trainX, train_y


train_X, train_y = seperate_data(train)
test_X, test_y = seperate_data(test)

train_X = np.array(train_X)
train_y = np.array(train_y)
test_X = np.array(test_X)
test_y = np.array(test_y)

def random_data(X,y):
    state = np.random.get_state()
    np.random.shuffle(X)
    np.random.set_state(state)
    np.random.shuffle(y)
    return X.T, y.T

train_X, train_y = random_data(train_X, train_y)
test_X, test_y = random_data(test_X, test_y)




        
        






