import os, sys
import numpy as np
import Evaluation as Ev
import Kmeans as km
import AccKmeans as ak
import SoftKmeans as sk
import Gmm as gm
from matplotlib import pyplot as plt

os.chdir(sys.path[0])

def read_data():
    f = open('seeds_dataset.txt', 'r')
    X = f.readlines()
    Xset = np.array( [list(map(float,i.split())) for i in X] )
    np.random.shuffle(Xset)
    X = Xset.T[:-1].T
    y = Xset.T[-1].astype(int)
    return X, y

X, y = read_data()

length = 30
plotX = [i for i in range(length)]

puritys_kmeans = []
ris_kmeans = []
nmis_kmeans = []
for i in range(length):
    model = km.Kmeans(RepeatTime=1)
    model.fit(X)
    class_kmeans = np.array(model.best_class)
    purity_kmeans = Ev.purity_score(y, class_kmeans)
    ri_kmeans = Ev.RI(y, class_kmeans)
    nmi_kmeans = Ev.NMI(y, class_kmeans)
    puritys_kmeans.append(purity_kmeans)
    ris_kmeans.append(ri_kmeans)
    nmis_kmeans.append(nmi_kmeans)
plt.title("Kmeans model")
plt.xlabel("No. n repeated initialization")
plt.plot(plotX, puritys_kmeans, label = "puritys")
plt.plot(plotX, ris_kmeans, label = 'Rand Index')
plt.plot(plotX, nmis_kmeans, label = 'Normalized Mutual Information')
plt.legend()
plt.show()

puritys_kmeans = []
ris_kmeans = []
nmis_kmeans = []
for i in range(length):
    model = ak.AccKmeans(RepeatTime=1)
    model.fit(X)
    class_kmeans = np.array(model.best_class)
    purity_kmeans = Ev.purity_score(y, class_kmeans)
    ri_kmeans = Ev.RI(y, class_kmeans)
    nmi_kmeans = Ev.NMI(y, class_kmeans)
    puritys_kmeans.append(purity_kmeans)
    ris_kmeans.append(ri_kmeans)
    nmis_kmeans.append(nmi_kmeans)
    model = 0
plt.title("Triangle Accelerated Kmeans model")
plt.xlabel("No. n repeated initialization")
plt.plot(plotX, puritys_kmeans, label = "puritys")
plt.plot(plotX, ris_kmeans, label = 'Rand Index')
plt.plot(plotX, nmis_kmeans, label = 'Normalized Mutual Information')
plt.legend()
plt.show()

puritys_kmeans = []
ris_kmeans = []
nmis_kmeans = []
for i in range(length):
    model = sk.SoftKmeans(RepeatTime=1)
    model.fit(X)
    class_kmeans = np.array(model.Class_hard)
    purity_kmeans = Ev.purity_score(y, class_kmeans)
    ri_kmeans = Ev.RI(y, class_kmeans)
    nmi_kmeans = Ev.NMI(y, class_kmeans)
    puritys_kmeans.append(purity_kmeans)
    ris_kmeans.append(ri_kmeans)
    nmis_kmeans.append(nmi_kmeans)
    model = 0
plt.title("Soft Kmeans model")
plt.xlabel("No. n repeated initialization")
plt.plot(plotX, puritys_kmeans, label = "puritys")
plt.plot(plotX, ris_kmeans, label = 'Rand Index')
plt.plot(plotX, nmis_kmeans, label = 'Normalized Mutual Information')
plt.legend()
plt.show()

puritys_kmeans = []
ris_kmeans = []
nmis_kmeans = []
for i in range(length):
    model = gm.Gmm()
    model.fit(X)
    class_kmeans = np.array(model.Class)
    purity_kmeans = Ev.purity_score(y, class_kmeans)
    ri_kmeans = Ev.RI(y, class_kmeans)
    nmi_kmeans = Ev.NMI(y, class_kmeans)
    puritys_kmeans.append(purity_kmeans)
    ris_kmeans.append(ri_kmeans)
    nmis_kmeans.append(nmi_kmeans)
    model = 0
plt.title("GMM-EM model")
plt.xlabel("No. n repeated initialization")
plt.plot(plotX, puritys_kmeans, label = "puritys")
plt.plot(plotX, ris_kmeans, label = 'Rand Index')
plt.plot(plotX, nmis_kmeans, label = 'Normalized Mutual Information')
plt.legend()
plt.show()

