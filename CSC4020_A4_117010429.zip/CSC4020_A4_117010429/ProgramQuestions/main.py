import os, sys
import numpy as np
import Evaluation as Ev
import Kmeans as km
import AccKmeans as ak
import SoftKmeans as sk
import Gmm as gm

os.chdir(sys.path[0])
def read_data():
    f = open('seeds_dataset.txt', 'r')
    X = f.readlines()
    Xset = np.array( [list(map(float,i.split())) for i in X] )
    np.random.shuffle(Xset)
    X = Xset.T[:-1].T
    y = Xset.T[-1].astype(int)
    return X, y

X, y = read_data()


model = km.Kmeans()
model.fit(X)
class_kmeans = np.array(model.best_class)
purity_kmeans = Ev.purity_score(y, class_kmeans)
ri_kmeans = Ev.RI(y, class_kmeans)
nmi_kmeans = Ev.NMI(y, class_kmeans)

model2 = ak.AccKmeans()
model2.fit(X)
class_Acckmeans = np.array(model2.best_class)
purity_Acckmeans = Ev.purity_score(y, class_Acckmeans)
ri_Acckmeans = Ev.RI(y, class_Acckmeans)
nmi_Acckmeans = Ev.NMI(y, class_Acckmeans)

model3 = sk.SoftKmeans()
model3.fit(X)
class_Softkmeans = np.array(model3.Class_hard)
purity_Softkmeans = Ev.purity_score(y, class_Softkmeans)
ri_Softkmeans = Ev.RI(y, class_Softkmeans)
nmi_Softkmeans = Ev.NMI(y, class_Softkmeans)

model4 = gm.Gmm()
model4.fit(X)
class_Gmm = np.array(model4.Class)
purity_Gmm = Ev.purity_score(y, class_Gmm)
ri_Gmm = Ev.RI(y, class_Gmm)
nmi_Gmm = Ev.NMI(y, class_Gmm)


print('----------------Kmeans Algorithm----------------' )
# print("The predict class is: ", class_kmeans)
print("The purity of kmeans algorithm is: ", purity_kmeans)
print("The RI of kmeans algorithm is: ", ri_kmeans)
print("The NMI of kmeans algorithm is: ", nmi_kmeans)
print("running time (for max 100 epochs and repeat 1 time) is: ", model.runtime, 's')
print("\n")

print('----------------Triangle Accelerated Kmeans Algorithm----------------' )
# print("The predict class is: ", class_Acckmeans+1)
print("The purity of triangle-accelerated kmeans algorithm is: ", purity_Acckmeans)
print("The RI of triangle-accelerate kmeans algorithm is: ", ri_Acckmeans)
print("The NMI of triangle-accelerate kmeans algorithm is: ", nmi_Acckmeans)
print("running time (for max 100 epochs and repeat 1 time) is: ", model2.runtime, 's')
print("\n")


print('----------------Soft Kmeans Algorithm----------------' )
# print("The predict class is: ", class_Softkmeans+1)
# print("The predict soft class is: ", model3.Class_Vector)
print("The purity of soft kmeans algorithm is: ", purity_Softkmeans)
print("The RI of soft kmeans algorithm is: ", ri_Softkmeans)
print("The NMI of soft kmeans algorithm is: ", nmi_Softkmeans)
print("running time (for max 100 epochs and repeat 1 time) is: ", model3.runtime, 's')
print("\n")


print('----------------Gmm-Em Algorithm----------------' )
# print("The predict class is: ", class_Gmm+1)
print("The purity of GMM-EM algorithm is: ", purity_Gmm)
print("The RI of GMM-EM algorithm is: ", ri_Gmm)
print("The NMI of GMM-EM algorithm is: ", nmi_Gmm)
print("running time (for max 100 epochs and repeat 1 time) is: ", model4.runtime, 's')
print("\n")

