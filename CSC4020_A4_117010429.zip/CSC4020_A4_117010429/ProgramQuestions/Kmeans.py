import numpy as np 
import time

class Kmeans(object):
    def __init__(self, K = 3, epoch = 100, RepeatTime = 1):
        self.K = K
        self.epoch = epoch
        self.Class = []
        self.RepeatTime = RepeatTime
        self.all_loss = []
        self.runtime = 0
        self.iter = 0
 
    def fit(self, X):
        t0 = time.perf_counter()
        for k in range(self.RepeatTime):
            self.train(X)
        min_loss = np.argmin(self.all_loss)
        best_class = self.Class[min_loss]
        self.min_loss = self.all_loss[min_loss]
        self.best_class = best_class
        t = time.perf_counter()
        self.runtime = t - t0

    def train(self, X):
        self.X = X
        cur_class = []
        Centroids = self.Random_generate(self.X)
        distances = self.distance(self.X, Centroids)
        Class = self.Class_assign(distances)
        for k in range(self.epoch):   
            Centroids = self.Re_centroid(self.X, Class)
            distances = self.distance(self.X, Centroids)
            newClass = self.Class_assign(distances)
            err = self.cacl_loss(self.X, Centroids, Class)
            if newClass == Class:
                self.all_loss.append(err)
                self.iter = k + 1
                break
            Class = newClass
        for i in Class:
            cur_class.append(i+1)
        self.Class.append(cur_class)
        
    def Random_generate(self, X):
        positions = np.random.randint(X.shape[0] , size=self.K) 
        Centroids = np.array([X[i] for i in positions])
        return Centroids

    def distance(self, X, Centroids):
        distances = []
        for x in X:
            dis = [np.linalg.norm(x - i) for i in Centroids ] 
            distances.append(dis)
        return np.array(distances)

    def Class_assign(self, distances):
        Class = []
        for dis in distances:
            Class.append(np.argmin(dis))
        return Class

    def Re_centroid(self, X, Class):
        all_class = [i for i in range(self.K)]
        new_centroids = []
        for i in range(len(all_class)):
            X_1c = []
            for j in range(len(Class)):
                if all_class[i] == Class[j]:
                    X_1c.append(X[j])
            new_centroids.append(np.mean(X_1c, axis=0))
        return np.array(new_centroids)
            
    def cacl_loss(self, X, Centroids, Class):
            return np.mean([np.linalg.norm(X[i] - Centroids[Class[i]]) for i in range(len(Class))] )








        

    
    
