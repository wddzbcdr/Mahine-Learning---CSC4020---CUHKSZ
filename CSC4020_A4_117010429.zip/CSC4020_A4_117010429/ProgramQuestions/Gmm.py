import numpy as np
import time

class Gmm(object):
    def __init__(self, K=3, epoch=100):
        self.K = K
        self.epoch = epoch
        self.mean = 0
        self.var = 0
        self.weight = 0
        self.runtime = 0
      
    def fit(self,X):
        t0 = time.perf_counter()
        self.X = X
        sam_num, fea_num = X.shape
        weight = np.ones(self.K) / self.K
        var = np.full((self.K,fea_num,fea_num), np.diag(np.full(fea_num,0.1)))
        mean = X[np.random.choice(range(sam_num), self.K)]
        for i in range(self.epoch):
            gamma = self.Gamma_calc(X, mean, var, weight)
            weight = np.sum(gamma,axis=0) / sam_num
            for i in range(self.K):
                mean[i] = np.sum(X*gamma[:,i].reshape((sam_num,1)),axis=0)/np.sum(gamma,axis=0)[i]
                var[i] = 0
                for j in range(sam_num): var[i] += (X[j].reshape((1,fea_num))-mean[i]).T.dot((X[j]-mean[i]).reshape((1,fea_num))) * gamma[j,i]
                var[i] = var[i]/np.sum(gamma,axis=0)[i]
        self.mean = mean
        self.var = var
        self.weight = weight
        t = time.perf_counter()
        pred = self.Gamma_calc(self.X, self.mean, self.var, self.weight)
        self.Class = np.argmax(pred, axis=1)
        self.runtime = t - t0

    def Gaussian_init(self, x, mean, var):
        return 1/((2*np.pi)*pow(np.linalg.det(var),0.5))*np.exp(-0.5*(x-mean).dot(np.linalg.pinv(var)).dot((x-mean).T))
 
    def Gamma_calc(self, X, mean, var, weight):
        sam_num=X.shape[0]
        K=len(weight)
        gamma=np.zeros((sam_num,K))
        p=np.zeros(K)
        g=np.zeros(K)
        for i in range(sam_num):
            for j in range(K):
                p[j]=self.Gaussian_init(X[i],mean[j],var[j])
                g[j]=weight[j]*p[j]
            for k in range(K): gamma[i,k]=g[k]/np.sum(g)
        return gamma


        
