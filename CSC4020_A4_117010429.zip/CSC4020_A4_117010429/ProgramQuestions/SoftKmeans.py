import numpy as np 
import time

class SoftKmeans(object):
    def __init__(self, K = 3, epoch = 10, RepeatTime = 100):
        self.K = K
        self.epoch = epoch
        self.Class = []
        self.RepeatTime = RepeatTime
        self.all_loss = []
        self.beta = 1
        self.iter = 0
        self.runtime = 0

    def fit(self, X):
        t0 = time.perf_counter()
        self.X = X
        Centroids = self.Random_generate(self.X)
        distances = self.distance(self.X, Centroids)
        Class_Vector = self.weight_calc(distances)
        for k in range(self.epoch):
            newCentroids = self.Re_centroid(self.X, Class_Vector)
            if newCentroids.all() == Centroids.all():
                self.iter = k + 1
                break
            Centroids = newCentroids
            distances = self.distance(self.X, Centroids)
            Class_Vector = self.weight_calc(distances)

        self.Class_Vector = Class_Vector
        self.Class_hard = self.Class_assign(Class_Vector)
        t = time.perf_counter()
        self.runtime = t - t0
            
    def Random_generate(self, X):
        positions = np.random.randint(X.shape[0] , size=self.K) 
        Centroids = np.array([X[i] for i in positions])
        return Centroids

    def distance(self, X, Centroids):
        distances = []
        for x in X:
            dis = [np.linalg.norm(x - i) for i in Centroids ] 
            distances.append(dis)
        return np.array(distances)

    def SoftMaxFunc(self, dis):
        exp_dis = np.exp(-self.beta*dis)
        return exp_dis / np.sum(exp_dis)

    def weight_calc(self, distances):
        Class_Vector = []
        for dis in distances:
            Class_Vector.append(self.SoftMaxFunc(dis))
        return np.array(Class_Vector)

    def Re_centroid(self, X, Class_Vector):
        Centoids = []
        for weight in Class_Vector.T:
            weighted_X = []
            weight_sum = np.sum(weight)
            for i in range(len(weight)):
                weighted_x = weight[i] * X[i] / weight_sum
                weighted_X.append(weighted_x)
            Centoids.append(np.sum(weighted_X, axis=0))
        Centoids = np.array(Centoids)
        return Centoids

    def Class_assign(self, Class_Vector):
        Class = []
        for cv in Class_Vector:
            Class.append(np.argmax(cv))
        return Class
                
         

