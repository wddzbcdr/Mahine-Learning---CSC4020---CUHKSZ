import numpy as np
import math

#purity
def purity_score(y, Class):
    y_voted_labels = np.zeros(y.shape)
    labels = np.unique(y)
    ordered_labels = np.arange(labels.shape[0])
    for k in range(labels.shape[0]):
        y[y==labels[k]] = ordered_labels[k]
    labels = np.unique(y)
    unique_Class = np.unique(Class)
    for cluster in unique_Class:
        winner = np.argmax(np.histogram(y[Class==cluster], np.concatenate((labels, [np.max(labels)+1]), axis=0))[0])
        y_voted_labels[Class==cluster] = winner
    accuracy = np.mean([1 if y[i]==y_voted_labels[i] else 0 for i in range(len(y))])
    return accuracy


# rand index
def RI(y, Class):
    N = len(Class)
    y_pairs = makePaires(y)
    Class_pairs = makePaires(Class)
    TP = np.sum([1 if y_pairs[i]==True and Class_pairs[i]==True else 0 for i in range(len(y_pairs))])
    TN = np.sum([1 if y_pairs[i]==False and Class_pairs[i]==False else 0 for i in range(len(y_pairs))])
    return (TP+TN)/((N*(N-1))/2)

def makePaires(Single):
    Pairs = []
    for i in range(len(Single)):
        for j in range(i+1,len(Single)):
            Pairs.append((Single[i] == Single[j]))
    return Pairs


# normal mutual information
def NMI(y, Class):
    total = len(y)
    y_ids = set(y)
    Class_ids = set(Class)
    MuInfo = 0
    eps = 1.4e-45
    for idA in y_ids:
        for idB in Class_ids:
            idAOccur = np.where(y==idA)
            idBOccur = np.where(Class==idB)
            idABOccur = np.intersect1d(idAOccur,idBOccur)
            px = len(idAOccur[0])/total
            py = len(idBOccur[0])/total
            pxy = len(idABOccur)/total
            MuInfo = MuInfo + pxy*math.log(pxy/(px*py)+eps,2)
    Hx = MuInfo_cacl(y_ids, Class, total, eps, MuInfo)
    Hy = MuInfo_cacl(Class_ids, Class, total, eps, MuInfo)
    return 2 * MuInfo/(Hx+Hy)

def MuInfo_cacl(c_ids, Class, total, eps, MuInfo):
    H = 0
    for idB in c_ids:
        idBOccurCount = len(np.where(Class == idB)[0])
        H = H - (idBOccurCount/total)*math.log(idBOccurCount/total+eps, 2)
    return H
    



