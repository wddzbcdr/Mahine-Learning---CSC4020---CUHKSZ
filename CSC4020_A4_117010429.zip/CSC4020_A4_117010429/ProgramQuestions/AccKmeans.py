import numpy as np 
import time

class AccKmeans(object):
    def __init__(self, K = 3, epoch = 100, RepeatTime = 1):
        self.K = K
        self.epoch = epoch
        self.RepeatTime = RepeatTime
        self.all_loss = []
        self.all_Class = []
        self.iter = 0

    def fit(self, X):
        t0 = time.perf_counter()
        self.X = X

        for k in range(self.RepeatTime):
            Centroids = self.Random_generate(self.X)
            cur_class = [-1 for i in range(self.X.shape[0])]
            for i in range(self.epoch):
                new_class = self.train(Centroids, cur_class)
                self.all_Class.append(new_class)
                Centroids = self.Re_centroid(self.X, cur_class)
                self.all_loss.append(self.cacl_loss(self.X, Centroids, cur_class))
                if cur_class == new_class:
                    self.Class = new_class
                    self.iter = i + 1
                    break
                cur_class = new_class
        min_loss = np.argmin(self.all_loss)
        best_class = self.all_Class[min_loss]
        self.best_class = best_class
        t = time.perf_counter()
        self.runtime = t - t0

    def train(self, Centroids, cur_class):
        distances_centroids = {}
        for i in range(len(Centroids)):
            for j in range(i+1,len(Centroids)):
                distances_centroids[(i, j)] = self.distance(Centroids[i], Centroids[j])

        for x_i in range(self.X.shape[0]):
            if cur_class[x_i] != -1:
                Ci = cur_class[x_i]
                Cj = self.find_closest(distances_centroids, Ci)
                if 2*self.distance(Centroids[Ci], self.X[x_i]) <= distances_centroids[(min((Ci, Cj)), max((Ci, Cj)))]:
                    pass
                else:
                    cur_class[x_i] = self.Class_assign(self.kmeans_distance(self.X[x_i], Centroids))
            else:
                for i in range(self.K):
                    Ci = i
                    Cj = self.find_closest(distances_centroids, Ci)
                    if 2*self.distance(Centroids[Ci], self.X[x_i]) <= distances_centroids[(min((Ci, Cj)), max((Ci, Cj)))]:
                        cur_class[x_i] = Ci
                        break
                    else:
                        cur_class[x_i] = self.Class_assign(self.kmeans_distance(self.X[x_i], Centroids))
        return cur_class

    def Random_generate(self, X):
        positions = np.random.randint(X.shape[0] , size=self.K) 
        Centroids = np.array([X[i] for i in positions])
        return Centroids

    def distance(self, A, B):
        return np.linalg.norm(A - B)

    def find_closest(self, distances_centroids, Ci):
        all_Cis = {}
        for i in distances_centroids:
            if Ci in i:
                all_Cis[i] = distances_centroids[i]
        sorted_all_Cis = sorted(all_Cis.items(), key=lambda x: x[1])
        CiCj = sorted_all_Cis[0][0]
        first = CiCj[0]
        second = CiCj[1]
        if first == Ci:
            return second
        else:
            return first

    def kmeans_distance(self, x, Centroids):
        dis = [np.linalg.norm(x - i) for i in Centroids] 
        return np.array(dis)
    
    def Class_assign(self, distances):
        return np.argmin(distances)

    def Re_centroid(self, X, Class):
        all_class = [i for i in range(self.K)]
        new_centroids = []
        for i in range(len(all_class)):
            X_1c = []
            for j in range(len(Class)):
                if all_class[i] == Class[j]:
                    X_1c.append(X[j])
            new_centroids.append(np.mean(X_1c, axis=0))
        return np.array(new_centroids)

    def cacl_loss(self, X, Centroids, Class):
        return np.mean([np.linalg.norm(X[i] - Centroids[Class[i]]) for i in range(len(Class))] )




                   


















        

    
    
