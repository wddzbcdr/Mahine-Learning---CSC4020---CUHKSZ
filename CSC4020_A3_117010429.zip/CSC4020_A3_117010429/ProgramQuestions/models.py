from sklearn.metrics import mean_squared_error
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn.ensemble import BaggingRegressor
from matplotlib import pyplot as plt
import numpy as np

X_train = np.load("X_train.npy")
X_test = np.load("X_test.npy")
y_train = np.load("y_train.npy")
y_test = np.load("y_test.npy")

def XYplot(X_set, Y_set, sse, Xlabel, Ylabel, multiLlabel, Bigtitle):
    for i in range(len(X_set)):
        plt.plot(Y_set, sse[i,:])
    label_set = []
    for k in X_set:
        label_set.append(multiLlabel + " = " + str(k))
    plt.xlabel(Xlabel)
    plt.ylabel(Ylabel)
    plt.title(Bigtitle)
    plt.legend(label_set)
    plt.show()

########################################################################################################################
#DecisionTreeRegressor

def DTR(max_depth, min_node):
    model = DecisionTreeRegressor(max_depth=max_depth, min_samples_leaf=min_node)
    model.fit(X_train, y_train)
    pred_train_y = model.predict(X_train)
    sse_Ta =  mean_squared_error(pred_train_y, y_train)*len(y_train)
    pred_test_y = model.predict(X_test)
    sse_Te = mean_squared_error(pred_test_y, y_test)*len(y_test)
    # print("max_depth = ", max_depth, " min_node = ", min_node)
    # print("DecisionTreeRegressor: The SSE in the train set is: ",sse_Ta)
    # print("DecisionTreeRegressor: The SSE in the test set is: ", sse_Tr, '\n')
    return sse_Ta, sse_Te

###Draw min_nodes vs SSE
max_depths = [1,3,5,10,50]
min_nodes = [i for i in range(1,21)]
sse_Tas = []
sse_Tes = []
for i in max_depths:
    Tas_maxdep = []
    Tes_maxdep = []
    for j in min_nodes:
        Ta, Te = DTR(i, j)
        Tas_maxdep.append(Ta)
        Tes_maxdep.append(Te)
    sse_Tas.append(Tas_maxdep)
    sse_Tes.append(Tes_maxdep)
sse_Tas = np.array(sse_Tas)
sse_Tes = np.array(sse_Tes)
print("SSE in Training Set: ",sse_Tas)
print("SSE in Testing Set: ",sse_Tes)
XYplot(max_depths, min_nodes, sse_Tas, Xlabel="min_nodes", Ylabel="SSE", multiLlabel="max_depth", Bigtitle="DecisionTreeRegressor: min_nodes vs SSE with different max_depth on training data")
XYplot(max_depths, min_nodes, sse_Tes, Xlabel="min_nodes", Ylabel="SSE", multiLlabel="max_depth", Bigtitle="DecisionTreeRegressor: min_nodes vs SSE with different max_depth on testing data")

###Draw max_depth vs SSE
max_depths = [i for i in range(1,51)]
min_nodes = [2,5,10,20]
sse_Tas = []
sse_Tes = []
for i in min_nodes:
    Tas_maxdep = []
    Tes_maxdep = []
    for j in max_depths:
        Ta, Te = DTR(j, i)
        Tas_maxdep.append(Ta)
        Tes_maxdep.append(Te)
    sse_Tas.append(Tas_maxdep)
    sse_Tes.append(Tes_maxdep)
sse_Tas = np.array(sse_Tas)
sse_Tes = np.array(sse_Tes)
print("SSE in Training Set: ",sse_Tas)
print("SSE in Testing Set: ",sse_Tes)
XYplot(min_nodes, max_depths, sse_Tas, Xlabel="max_depth", Ylabel="SSE", multiLlabel="min_nodes", Bigtitle="DecisionTreeRegressor: max_depth vs SSE with different min_nodes on training data")
XYplot(min_nodes, max_depths, sse_Tes, Xlabel="max_depth", Ylabel="SSE", multiLlabel="min_nodes", Bigtitle="DecisionTreeRegressor: max_depth vs SSE with different min_nodes on testing data")
########################################################################################################################
#DecisionTreeRegressor + BaggingRegressor
def DTR_Bag(max_depth, n_trees):
    model = DecisionTreeRegressor(max_depth=max_depth)
    model2 = BaggingRegressor(model, n_estimators=n_trees)
    model2.fit(X_train, y_train)
    pred_train_y = model2.predict(X_train)
    sse_Ta = mean_squared_error(pred_train_y, y_train)*len(y_train)
    pred_test_y = model2.predict(X_test)
    sse_Te = mean_squared_error(pred_test_y, y_test)*len(y_test)    # print("max_depth = ", max_depth, " n_trees = ", n_trees)
    # print("DecisionTreeRegressor + BaggingRegressor: The SSE in the train set is: ", sse_Ta)
    # print("DecisionTreeRegressor + BaggingRegressor: The SSE in the test set is: ", sse_Tr, '\n')
    return sse_Ta, sse_Te

###Draw n_trees vs SSE
max_depths = [1,3,5,10,50]
n_trees = [i for i in range(1,101)]
sse_Tas_DB = []
sse_Tes_DB = []

for i in max_depths:
    Tas_maxdep_DB = []
    Tes_maxdep_DB = []
    for j in n_trees:
        Ta, Te = DTR_Bag(i, j)
        Tas_maxdep_DB.append(Ta)
        Tes_maxdep_DB.append(Te)
    sse_Tas_DB.append(Tas_maxdep_DB)
    sse_Tes_DB.append(Tes_maxdep_DB)
sse_Tas_DB = np.array(sse_Tas_DB)
sse_Tes_DB = np.array(sse_Tes_DB)
print("SSE in Training Set: ",sse_Tas_DB)
print("SSE in Testing Set: ",sse_Tes_DB)
XYplot(max_depths, n_trees, sse_Tas_DB, Xlabel="n_trees", Ylabel="SSE", multiLlabel="max_depth", Bigtitle="Bagging of Trees Regressor: n_trees vs SSE with different max_depth on training data")
XYplot(max_depths, n_trees, sse_Tes_DB, Xlabel="n_trees", Ylabel="SSE", multiLlabel="max_depth", Bigtitle="Bagging of Trees Regressor: n_trees vs SSE with different max_depth on testing data")

###Draw max_depths vs SSE
max_depths = [i for i in range(1,51)]
n_trees = [5,20,50,100]
sse_Tas_DB = []
sse_Tes_DB = []
for i in n_trees:
    Tas_maxdep_DB = []
    Tes_maxdep_DB = []
    for j in max_depths:
        Ta, Te = DTR_Bag(j, i)
        Tas_maxdep_DB.append(Ta)
        Tes_maxdep_DB.append(Te)
    sse_Tas_DB.append(Tas_maxdep_DB)
    sse_Tes_DB.append(Tes_maxdep_DB)
sse_Tas_DB = np.array(sse_Tas_DB)
sse_Tes_DB = np.array(sse_Tes_DB)
print("SSE in Training Set: ",sse_Tas_DB)
print("SSE in Testing Set: ",sse_Tes_DB)
XYplot(n_trees, max_depths, sse_Tas_DB, Xlabel="max_depths", Ylabel="SSE", multiLlabel="n_trees", Bigtitle="Bagging of Trees Regressor: max_depths vs SSE with different n_trees on training data")
XYplot(n_trees, max_depths, sse_Tes_DB, Xlabel="max_depths", Ylabel="SSE", multiLlabel="n_trees", Bigtitle="Bagging of Trees Regressor: max_depths vs SSE with different n_trees on testing data")
########################################################################################################################



#DecisionTreeRegressor + RandomForestRegressor
def DTR_RF(mtry, n_trees):
    model3 = RandomForestRegressor(n_estimators=n_trees, max_features=mtry)
    model3.fit(X_train, y_train)
    pred_train_y = model3.predict(X_train)
    sse_Ta = mean_squared_error(pred_train_y, y_train)*len(y_train)
    pred_test_y = model3.predict(X_test)
    sse_Te = mean_squared_error(pred_test_y, y_test)*len(y_test)
    # print("DecisionTreeRegressor + RandomForestRegressor: The SSE in the train set is: ", mean_squared_error(pred_train_y, y_train)*len(y_train))
    # print("DecisionTreeRegressor + RandomForestRegressor: The SSE in the test set is: ", mean_squared_error(pred_test_y, y_test)*len(y_test), '\n')
    return sse_Ta, sse_Te

###Draw n_trees vs SSE
mtry = [1,3,5,7,9]
n_trees = [i for i in range(1,101)]
sse_Tas_DB = []
sse_Tes_DB = []
for i in mtry:
    Tas_maxdep_DB = []
    Tes_maxdep_DB = []
    for j in n_trees:
        Ta, Te = DTR_RF(i, j)
        Tas_maxdep_DB.append(Ta)
        Tes_maxdep_DB.append(Te)
    sse_Tas_DB.append(Tas_maxdep_DB)
    sse_Tes_DB.append(Tes_maxdep_DB)
sse_Tas_DB = np.array(sse_Tas_DB)
sse_Tes_DB = np.array(sse_Tes_DB)
print("SSE in Training Set: ",sse_Tas_DB)
print("SSE in Testing Set: ",sse_Tes_DB)
XYplot(mtry, n_trees, sse_Tas_DB, Xlabel="n_trees", Ylabel="SSE", multiLlabel="mtry", Bigtitle="Random Forests Regressor: n_trees vs SSE with different mtry on training data")
XYplot(mtry, n_trees, sse_Tes_DB, Xlabel="n_trees", Ylabel="SSE", multiLlabel="mtry", Bigtitle="Random Forests Regressor: n_trees vs SSE with different mtry on testing data")


#DecisionTreeRegressor + AdaBoostRegressor
def DTR_AB(n_trees):
    model = DecisionTreeRegressor()
    model.fit(X_train, y_train)
    model4 = AdaBoostRegressor(model, n_estimators=n_trees)
    model4.fit(X_train, y_train)
    pred_train_y = model4.predict(X_train)
    sse_Ta = mean_squared_error(pred_train_y, y_train)*len(y_train)
    pred_test_y = model4.predict(X_test)
    sse_Te = mean_squared_error(pred_test_y, y_test)*len(y_test)
    return sse_Ta, sse_Te

###Draw n_trees vs SSE
n_trees = [i for i in range(1,101)]
sse_Tas_DB = []
sse_Tes_DB = []
for i in n_trees:
    Ta, Te = DTR_AB(i)
    sse_Tas_DB.append(Ta)
    sse_Tes_DB.append(Te)
sse_Tas_DB = np.array(sse_Tas_DB)
sse_Tes_DB = np.array(sse_Tes_DB)
print("SSE in Training Set: ",sse_Tas_DB)
print("SSE in Testing Set: ",sse_Tes_DB)
plt.xlabel("n_trees")
plt.ylabel("SSE")
plt.title("Decision Tree + Adaboost Regressor: n_trees vs SSE on training data")
plt.plot(n_trees, sse_Tas_DB)
plt.show()

plt.xlabel("n_trees")
plt.ylabel("SSE")
plt.title("Decision Tree + Adaboost Regressor: n_trees vs SSE on testing data")
plt.plot(n_trees, sse_Tes_DB)
plt.show()


