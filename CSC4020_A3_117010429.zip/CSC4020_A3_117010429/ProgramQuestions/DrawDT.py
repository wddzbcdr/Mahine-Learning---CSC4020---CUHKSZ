from sklearn.tree import DecisionTreeRegressor
from sklearn.tree import export_graphviz
import numpy as np

X_train = np.load("X_train.npy")
y_train = np.load("y_train.npy")
model_draw = DecisionTreeRegressor(max_depth=8)
model_draw.fit(X_train, y_train)

feature_names=['ComPrice','Income','Advertising','Population','Price','ShelveLoc', 'Age', 'Education','Urban', 'US']
export_graphviz(
        model_draw,
        out_file="tree_re.dot",
        feature_names=feature_names,
        rounded=True,
        filled=True
    )