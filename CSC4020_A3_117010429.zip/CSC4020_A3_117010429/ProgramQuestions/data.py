import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt
import plotly.graph_objs as go
from plotly.offline import iplot 
from sklearn.model_selection import train_test_split

df = pd.read_csv("Carseats.csv")
Sales = df["Sales"].apply(lambda x: float(x))
CompPrice = df["CompPrice"].apply(lambda x: float(x))
Income = df["Income"].apply(lambda x: float(x))
Advertising = df["Advertising"].apply(lambda x: float(x))
Population = df["Population"].apply(lambda x: float(x))
Price = df["Price"].apply(lambda x: float(x))
ShelveLoc = df["ShelveLoc"]
Age = df["Age"].apply(lambda x: float(x))
Education = df["Education"].apply(lambda x: float(x))
Urban = df["Urban"]
US = df["US"]

def Bin2Int(data):
    if data == 'Yes':
        return 1
    else:
        return 0

dc_US = US.map(Bin2Int)
dc_Ub = Urban.map(Bin2Int)

def MultiClass2Int(data):
    if data == 'Bad':
        return 0
    elif data == 'Medium':
        return 1
    else:
        return 2
dc_SL = ShelveLoc.map(MultiClass2Int)
X = pd.concat([CompPrice, Income, Advertising, Population, Price, dc_SL, Age, Education, dc_Ub, dc_SL], axis=1)
y = df['Sales']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)

np.save("X_train.npy", X_train)
np.save("X_test.npy", X_test)
np.save("y_train.npy", y_train)
np.save("y_test.npy", y_test)

print("The data is successfully disorgnized!")










