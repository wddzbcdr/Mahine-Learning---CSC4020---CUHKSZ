from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import BaggingRegressor
from sklearn.ensemble import RandomForestRegressor
import numpy as np
from matplotlib import pyplot as plt
# Calculate out-of-box error
# only usible on Bagging algorthm (includs RandomForests)
X_train =  np.load("X_train.npy")
y_train  = np.load("y_train.npy")

def Bagging_OOB():
    n_trees = [i for i in range(1,101)]
    max_depths = [i for i in range(1,101)]
    OOB_Bag_nt = []
    OOB_Bag_md = []
    for i in n_trees:
        model_DT = DecisionTreeRegressor()
        model = BaggingRegressor(model_DT, n_estimators=i, oob_score=True)
        model.fit(X_train, y_train)
        OOB_Bag_nt.append(1 - model.oob_score_)
    for i in max_depths:
        model_DT = DecisionTreeRegressor(max_depth=i)
        model = BaggingRegressor(model_DT, oob_score=True)
        model.fit(X_train, y_train)
        OOB_Bag_md.append(1 - model.oob_score_)
    return OOB_Bag_nt, OOB_Bag_md

oob_nts, oob_mds = Bagging_OOB()

x_nts = [i for i in range(1,101)]
plt.xlabel("n_trees")
plt.ylabel("OOB error")
plt.title("DecisionTree + Bagging: n_trees vs OOB error")
plt.plot(x_nts, oob_nts)
plt.show()

x_mds = [i for i in range(1,101)]
plt.xlabel("max_depth")
plt.ylabel("OOB error")
plt.title("DecisionTree + Bagging: max_depth vs OOB error")
plt.plot(x_mds, oob_mds)
plt.show()


def RF_OOB():
    n_trees = [i for i in range(1,101)]
    mtry = [i for i in range(1,11)]
    OOB_RF_nt = []
    OOB_RF_mtry = []
    for i in n_trees:
        model = RandomForestRegressor(n_estimators=i, oob_score=True)
        model.fit(X_train, y_train)
        OOB_RF_nt.append(1 - model.oob_score_)
    for i in mtry:
        model = RandomForestRegressor(max_features=i, oob_score=True)
        model.fit(X_train, y_train)
        OOB_RF_mtry.append(1 - model.oob_score_)
    return OOB_RF_nt, OOB_RF_mtry

oob_nts, oob_mtrys = RF_OOB()

x_nts = [i for i in range(1,101)]
plt.xlabel("n_trees")
plt.ylabel("OOB error")
plt.title("RandomForests: n_trees vs OOB error")
plt.plot(x_nts, oob_nts)
plt.show()
   
x_mtrys = [i for i in range(1,11)]
plt.xlabel("mtry")
plt.ylabel("OOB error")
plt.title("RandomForests: mtry vs OOB error")
plt.plot(x_mtrys, oob_mtrys)
plt.show()