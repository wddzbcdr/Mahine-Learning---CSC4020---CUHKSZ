#This file is to random data
#The randomed data is saved in files, but if you want to repeat random you can run this file. 
#By the way you should fill suitable file path.

import numpy as np
def data():
    #The path to read raw data
    f = open("/Users/zong/Desktop/Class/大四Term2/CSC4020/Assignments/Assignment1/spam.data")
    lines = f.readlines()
    L = []
    for i in lines:
        the_row = i.split()
        the_row = [float(k) for k in the_row]
        data = the_row
        L.append(data)
    np.random.shuffle(L)

    X = []
    Y = []
    for i in L:
        X.append(i[:-1])
        Y.append(int(i[-1]))
    return X, Y

#The path to save data(X) and label(Y)
file_handle_X=open('/Users/zong/Desktop/Class/大四Term2/CSC4020/Assignments/Assignment1/X.txt',mode='w')
file_handle_Y=open('/Users/zong/Desktop/Class/大四Term2/CSC4020/Assignments/Assignment1/Y.txt',mode='w')
X, Y = data()

for i in X:
    for j in i:
        file_handle_X.write(str(j))
        file_handle_X.write(' ')
    file_handle_X.write('\n')
for i in Y:
    file_handle_Y.write(str(i))
    file_handle_Y.write('\n')


