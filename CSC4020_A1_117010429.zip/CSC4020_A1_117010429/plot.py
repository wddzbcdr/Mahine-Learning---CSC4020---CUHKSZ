###In this file you can plot iterative curve for different experiments
###By the way, you should care about the file path for each dataset(You'd better use absolute path in your own computer！)

import matplotlib.pyplot as plt

#The file which saves output data!!!!!!!!!!!!!
local_path = "CSC_4020_A1_117010429/outputdata/"  

f_acc = open(local_path+"train_acc.txt")
acc = f_acc.readlines()
for i in range(len(acc)):
    acc[i] = float(acc[i])
f_err = open(local_path+"train_err.txt")
err = f_err.readlines()
for i in range(len(err)):
    err[i] = float(err[i])

f_tacc = open(local_path+"test_acc.txt")
tacc = f_tacc.readlines()
for i in range(len(tacc)):
    tacc[i] = float(tacc[i])
f_terr = open(local_path+"test_err.txt")
terr = f_terr.readlines()
for i in range(len(terr)):
    terr[i] = float(terr[i])


f_acc_0_01 = open(local_path+"l2_0_01_train_acc.txt")
acc_0_01 = f_acc_0_01.readlines()
for i in range(len(acc_0_01)):
    acc_0_01[i] = float(acc_0_01[i])
f_err_0_01 = open(local_path+"l2_0_01_train_err.txt")
err_0_01 = f_err_0_01.readlines()
for i in range(len(err_0_01)):
    err_0_01[i] = float(err_0_01[i])

f_tacc_0_01 = open(local_path+"l2_0_01_test_acc.txt")
tacc_0_01 = f_tacc_0_01.readlines()
for i in range(len(tacc_0_01)):
    tacc_0_01[i] = float(tacc_0_01[i])
f_terr_0_01 = open(local_path+"l2_0_01_test_err.txt")
terr_0_01 = f_terr_0_01.readlines()
for i in range(len(terr_0_01)):
    terr_0_01[i] = float(terr_0_01[i])


f_acc_0_001 = open(local_path+"l2_0_001_train_acc.txt")
acc_0_001 = f_acc_0_001.readlines()
for i in range(len(acc_0_001)):
    acc_0_001[i] = float(acc_0_001[i])
f_err_0_001 = open(local_path+"l2_0_001_train_err.txt")
err_0_001 = f_err_0_001.readlines()
for i in range(len(err_0_001)):
    err_0_001[i] = float(err_0_001[i])

f_tacc_0_001 = open(local_path+"l2_0_001_test_acc.txt")
tacc_0_001 = f_tacc_0_001.readlines()
for i in range(len(tacc_0_001)):
    tacc_0_001[i] = float(tacc_0_001[i])
f_terr_0_001 = open(local_path+"l2_0_001_test_err.txt")
terr_0_001 = f_terr_0_001.readlines()
for i in range(len(terr_0_001)):
    terr_0_001[i] = float(terr_0_001[i])


f_acc_0_0001 = open(local_path+"l2_0_0001_train_acc.txt")
acc_0_0001 = f_acc_0_0001.readlines()
for i in range(len(acc_0_0001)):
    acc_0_0001[i] = float(acc_0_0001[i])
f_err_0_0001 = open(local_path+"l2_0_0001_train_err.txt")
err_0_0001 = f_err_0_0001.readlines()
for i in range(len(err_0_0001)):
    err_0_0001[i] = float(err_0_0001[i])

f_tacc_0_0001 = open(local_path+"l2_0_0001_test_acc.txt")
tacc_0_0001 = f_tacc_0_0001.readlines()
for i in range(len(tacc_0_0001)):
    tacc_0_0001[i] = float(tacc_0_0001[i])
f_terr_0_0001 = open(local_path+"l2_0_0001_test_err.txt")
terr_0_0001 = f_terr_0_0001.readlines()
for i in range(len(terr_0_0001)):
    terr_0_0001[i] = float(terr_0_0001[i])

f_l1_acc_0_01 = open(local_path+"l1_0_01_train_acc.txt")
acc_l1_0_01 = f_l1_acc_0_01.readlines()
for i in range(len(acc_l1_0_01)):
    acc_l1_0_01[i] = float(acc_l1_0_01[i])
f_l1_err_0_01 = open(local_path+"l1_0_01_train_err.txt")
err_l1_0_01 = f_l1_err_0_01.readlines()
for i in range(len(err_l1_0_01)):
    err_l1_0_01[i] = float(err_l1_0_01[i])

f_l1_tacc_0_01 = open(local_path+"l1_0_01_test_acc.txt")
tacc_l1_0_01 = f_l1_tacc_0_01.readlines()
for i in range(len(tacc_l1_0_01)):
    tacc_l1_0_01[i] = float(tacc_l1_0_01[i])
f_l1_terr_0_01 = open(local_path+"l1_0_01_test_err.txt")
terr_l1_0_01 = f_l1_terr_0_01.readlines()
for i in range(len(terr_l1_0_01)):
    terr_l1_0_01[i] = float(terr_l1_0_01[i])

f_l1_acc_0_001 = open(local_path+"l1_0_001_train_acc.txt")
acc_l1_0_001 = f_l1_acc_0_001.readlines()
for i in range(len(acc_l1_0_001)):
    acc_l1_0_001[i] = float(acc_l1_0_001[i])
f_l1_err_0_001 = open(local_path+"l1_0_001_train_err.txt")
err_l1_0_001 = f_l1_err_0_001.readlines()
for i in range(len(err_l1_0_001)):
    err_l1_0_001[i] = float(err_l1_0_001[i])

f_l1_tacc_0_001 = open(local_path+"l1_0_001_test_acc.txt")
tacc_l1_0_001 = f_l1_tacc_0_001.readlines()
for i in range(len(tacc_l1_0_001)):
    tacc_l1_0_001[i] = float(tacc_l1_0_001[i])
f_l1_terr_0_001 = open(local_path+"l1_0_001_test_err.txt")
terr_l1_0_001 = f_l1_terr_0_001.readlines()
for i in range(len(terr_l1_0_001)):
    terr_l1_0_001[i] = float(terr_l1_0_001[i])

f_l1_acc_0_0001 = open(local_path+"l1_0_0001_train_acc.txt")
acc_l1_0_0001 = f_l1_acc_0_0001.readlines()
for i in range(len(acc_l1_0_0001)):
    acc_l1_0_0001[i] = float(acc_l1_0_0001[i])
f_l1_err_0_0001 = open(local_path+"l1_0_0001_train_err.txt")
err_l1_0_0001 = f_l1_err_0_0001.readlines()
for i in range(len(err_l1_0_0001)):
    err_l1_0_0001[i] = float(err_l1_0_0001[i])

f_l1_tacc_0_0001 = open(local_path+"l1_0_0001_test_acc.txt")
tacc_l1_0_0001 = f_l1_tacc_0_0001.readlines()
for i in range(len(tacc_l1_0_0001)):
    tacc_l1_0_0001[i] = float(tacc_l1_0_0001[i])
f_l1_terr_0_0001 = open(local_path+"l1_0_0001_test_err.txt")
terr_l1_0_0001 = f_l1_terr_0_0001.readlines()
for i in range(len(terr_l1_0_0001)):
    terr_l1_0_0001[i] = float(terr_l1_0_0001[i])

x = [i for i in range(len(err))]
plt.title('LogisticRegression')
plt.xlabel('# of iterations')


a = input("Which version of curve you would like to see? please enter r/l1/l2 (r: regular version): ")
eoa = input("Will you see accuracy or error curve? Please enter acc/err: ")
if a == 'r':
    if eoa == 'err':
        plt.xlabel('# of iterations')
        plt.ylabel('error')
        plt.plot(x[10:], err[10:], label = 'training set')
        plt.plot(x[10:], terr[10:], label = 'test set')
    elif eoa == 'acc':
        plt.xlabel('# of iterations')
        plt.ylabel('accracy')
        plt.plot(x, acc,  label = 'training set')
        plt.plot(x, tacc,  label = 'test set')

elif a == 'l1' or 'l2':
    ld = input("Please choose parameter lambda (0.01/0.001/0.0001): ")
    if eoa == 'err':
        plt.xlabel('# of iterations')
        plt.ylabel('error')
        plt.plot(x[10:], err[10:], label = 'training set')
        plt.plot(x[10:], terr[10:], label = 'test set')
        if a == 'l1':
            if ld == '0.01':
                plt.plot(x[10:], err_l1_0_01[10:], label = 'training set for l1 and lambda = 0.01')
                plt.plot(x[10:], terr_l1_0_01[10:], label = 'test set for l1 and lambda = 0.01')
            elif ld == '0.001':
                plt.plot(x[10:], err_l1_0_001[10:], label = 'training set for l1 and lambda = 0.001')
                plt.plot(x[10:], terr_l1_0_001[10:], label = 'test set for l1 and lambda = 0.001')
            elif ld == '0.0001':
                plt.plot(x[10:], err_l1_0_0001[10:], label = 'training set for l1 and lambda = 0.0001')
                plt.plot(x[10:], terr_l1_0_0001[10:], label = 'test set for l1 and lambda = 0.0001')
            else:
                print("Input error, Please input the number among 0.01/0.001/0.0001")

        elif a == 'l2':
            if ld == '0.01':
                plt.plot(x[10:], err_0_01[10:], label = 'training set for l2 and lambda = 0.01')
                plt.plot(x[10:], terr_0_01[10:], label = 'test set for l2 and lambda = 0.01')
            elif ld == '0.001':
                plt.plot(x[10:], err_0_001[10:], label = 'training set for l2 and lambda = 0.001')
                plt.plot(x[10:], terr_0_001[10:], label = 'test set for l2 and lambda = 0.001')
            elif ld == '0.0001':
                plt.plot(x[10:], err_0_0001[10:], label = 'training set for l2 and lambda = 0.0001')
                plt.plot(x[10:], terr_0_0001[10:], label = 'test set for l2 and lambda = 0.0001')
            else:
                print("Input error, Please input the number among 0.01/0.001/0.0001")
        
        else:
            print("Input error, Please input g/l1/l2.")

    elif eoa == 'acc':
        plt.xlabel('# of iterations')
        plt.ylabel('accuracy')
        plt.plot(x, acc,  label = 'training set')
        plt.plot(x, tacc,  label = 'test set')
        if a == 'l1':
            if ld == '0.01':
                plt.plot(x, acc_l1_0_01,  label = 'training set for l1 and lambda = 0.01')
                plt.plot(x, tacc_l1_0_01,  label = 'test set for l1 and lambda = 0.01')
            elif ld == '0.001':
                plt.plot(x, acc_l1_0_001,  label = 'training set for l1 and lambda = 0.001')
                plt.plot(x, tacc_l1_0_001,  label = 'test set for l1 and lambda = 0.001')
            elif ld == '0.0001':
                plt.plot(x, acc_l1_0_0001,  label = 'training set for l1 and lambda = 0.0001')
                plt.plot(x, tacc_l1_0_0001,  label = 'test set for l1 and lambda = 0.0001')
            else:
                print("Input error, Please input the number among 0.01/0.001/0.0001")
        elif a == 'l2':
            if ld == '0.01':
                plt.plot(x, acc_0_01,  label = 'training set for l2 and lambda = 0.01')
                plt.plot(x, tacc_0_01,  label = 'test set for l2 and lambda = 0.01')
            elif ld == '0.001':
                plt.plot(x, acc_0_001,  label = 'training set for l2 and lambda = 0.001')
                plt.plot(x, tacc_0_001,  label = 'test set for l2 and lambda = 0.001')
            elif ld == '0.0001':
                plt.plot(x, acc_0_0001,  label = 'training set for l2 and lambda = 0.0001')
                plt.plot(x, tacc_0_0001,  label = 'test set for l2 and lambda = 0.0001')
            else:
                print("Input error, Please input the number among 0.01/0.001/0.0001")
        else:
            print("Input error, Please input g/l1/l2.")

    else:
        print("Input error, Please input err/acc")

plt.legend()
plt.show()

            

            



        










###add y label: error
# plt.ylabel('error')

### plot general train and test error curve
# plt.plot(x[10:], err[10:], label = 'training set')
# plt.plot(x[10:], terr[10:], label = 'test set')

############l2 generalization for error############
### plot l2 and lambda = 0.01 train and test error curve
# plt.plot(x[10:], err_0_01[10:], label = 'training set for l2 and lambda = 0.01')
# plt.plot(x[10:], terr_0_01[10:], label = 'test set for l2 and lambda = 0.01')

### plot l2 and lambda = 0.001 train and test error curve
# plt.plot(x[10:], err_0_001[10:], label = 'training set for l2 and lambda = 0.001')
# plt.plot(x[10:], terr_0_001[10:], label = 'test set for l2 and lambda = 0.001')

### plot l2 and lambda = 0.001 train and test error curve
# plt.plot(x[10:], err_0_0001[10:], label = 'training set for l2 and lambda = 0.0001')
# plt.plot(x[10:], terr_0_0001[10:], label = 'test set for l2 and lambda = 0.0001')
############l2 generalization for error end############

############l1 generalization for error############
### plot l1 and lambda = 0.01 train and test error curve
# plt.plot(x[10:], err_l1_0_01[10:], label = 'training set for l1 and lambda = 0.01')
# plt.plot(x[10:], terr_l1_0_01[10:], label = 'test set for l1 and lambda = 0.01')

### plot l1 and lambda = 0.001 train and test error curve
# plt.plot(x[10:], err_l1_0_001[10:], label = 'training set for l1 and lambda = 0.001')
# plt.plot(x[10:], terr_l1_0_001[10:], label = 'test set for l1 and lambda = 0.001')

### plot l1 and lambda = 0.0001 train and test error curve
# plt.plot(x[10:], err_l1_0_0001[10:], label = 'training set for l1 and lambda = 0.0001')
# plt.plot(x[10:], terr_l1_0_0001[10:], label = 'test set for l1 and lambda = 0.0001')
############l1 generalization for error end############

###add y label: accuracy
# plt.ylabel('accuracy')

### plot general train and test acc curve
# plt.plot(x, acc,  label = 'training set')
# plt.plot(x, tacc,  label = 'test set')

############l2 generalization for acc############
### plot l2 and lambda = 0.01 train and test acc curve
# plt.plot(x, acc_0_01,  label = 'training set for l2 and lambda = 0.01')
# plt.plot(x, tacc_0_01,  label = 'test set for l2 and lambda = 0.01')

### plot l2 and lambda = 0.001 train and test acc curve
# plt.plot(x, acc_0_001,  label = 'training set for l2 and lambda = 0.001')
# plt.plot(x, tacc_0_001,  label = 'test set for l2 and lambda = 0.001')

### plot l2 and lambda = 0.0001 train and test acc curve
# plt.plot(x, acc_0_0001,  label = 'training set for l2 and lambda = 0.0001')
# plt.plot(x, tacc_0_0001,  label = 'test set for l2 and lambda = 0.0001')
############l2 generalization for acc end############

############l1 generalization for acc############
### plot l1 and lambda = 0.01 train and test acc curve
# plt.plot(x, acc_l1_0_01,  label = 'training set for l1 and lambda = 0.01')
# plt.plot(x, tacc_l1_0_01,  label = 'test set for l1 and lambda = 0.01')

### plot l1 and lambda = 0.001 train and test acc curve
# plt.plot(x, acc_l1_0_001,  label = 'training set for l1 and lambda = 0.001')
# plt.plot(x, tacc_l1_0_001,  label = 'test set for l1 and lambda = 0.001')

### plot l1 and lambda = 0.0001 train and test acc curve
# plt.plot(x, acc_l1_0_0001,  label = 'training set for l1 and lambda = 0.0001')
# plt.plot(x, tacc_l1_0_0001,  label = 'test set for l1 and lambda = 0.0001')
############l1 generalization for acc end############



