import numpy as np
import random

class LogisticRegression():
    def __init__(self, lr = 0.1, max_iter = 1000):
        self.lr = lr
        self.max_iter = max_iter
        self.train_error_list = []
        self.train_accrancy_list = []
        self.test_error_list = []
        self.test_accrancy_list = []

    def fit(self, x, y, x_test, y_test, reg, ld):
        self.x = x
        self.y = y
        self.x_test = x_test
        self.y_test = y_test
        self.w = np.random.normal(loc=0.0, scale=1.0, size=x.shape[1])
        self.b = np.random.normal(loc=0.0, scale=1.0)
        
        for i in range(self.max_iter):
            self.train(reg=reg, ld=ld)
            print("The iter No.", i)
            acc = self.cacl_acc()*100
            print("The accurancy in the training set is: ", acc , "%")
            self.train_accrancy_list.append(acc)
            err = self.error()
            print("The training error is: ", err)
            self.train_error_list.append(err)

            test_acc = self.cacl_test_acc()*100
            print("The accurancy in the test set is: ", test_acc , "%")
            self.test_accrancy_list.append(test_acc)
            test_err = self.test_error(self.x_test, self.y_test)
            print("The test error is: ", test_err)
            self.test_error_list.append(test_err)

    def sigmoid(self, z):
        return 1.0 / (1.0 + (np.e)**(-z) )

    def f(self, x, w, b):
        return self.sigmoid(x.dot(w) + b)

    def predict(self, x, binary = False):
        y_pred = self.f(x, self.w, self.b)
        y_pred_bi = np.array( [0 if y_pred[i] < 0.5 else 1 for i in range(len(y_pred))] )
        if binary == True:
            return y_pred_bi
        else:
            return y_pred
        
    def calc_grad(self, regularlization = None, ld = 0.01):
        y_pred = self.predict(self.x)
        d_w = (y_pred - self.y).dot(self.x) / len(self.y)
        d_b = np.mean(y_pred - self.y)

        ld = ld
        if regularlization == 'l1':
            d_w += ld * np.sign(self.w)
        elif regularlization == 'l2':
            d_w += ld * 2 * self.w
        return d_w, d_b

    def error(self):
        y_pred = self.predict(self.x)
        error = 0
        for i in range(len(y_pred)):
            error += self.y[i] * np.log(y_pred[i]) + (1-self.y[i])*np.log(1-y_pred[i])
        return -error/len(y_pred)
    
    def test_error(self, x_test, y_test):
        y_pred = self.predict(x_test)
        error = 0
        for i in range(len(y_pred)):
            error += y_test[i] * np.log(y_pred[i]) + (1-y_test[i])*np.log(1-y_pred[i])
        return -error/len(y_pred)
            
    def train(self, reg = 'None', ld = 0.01):
        dw, db = self.calc_grad(regularlization=reg, ld = ld)
        self.w -= self.lr * dw
        self.b -= self.lr * db
        return self.w, self.b

    def cacl_acc(self, y = None, y_pred = None):
        if y==None:
            y = self.y
        y_pred = self.predict(self.x, binary = True)
        acc = np.mean([0 if y[i] != y_pred[i] else 1 for i in range(len(y))])
        return acc
    
    def cacl_test_acc(self):
        y_pred = self.predict(self.x_test, binary=True)
        acc = np.mean([0 if self.y_test[i] != y_pred[i] else 1 for i in range(len(self.y_test))])
        return acc

def normalization(X):
    NX = []
    for i in X:
        mean_i = np.mean(i)
        interal = [ (i[j]-mean_i)**2 for j in range(len(i))]
        s = ( np.sum(interal)/(len(i)-1) )**(1/2)
        new = [ (i[k]-mean_i)/s for k in range(len(i))]
        NX.append(new)
    return NX

## Be careful! Here you should change the absolute path in your own computer!
def read_data(add_x0 = True):
    fx = open("X.txt")
    X_raw = fx.readlines()
    X = []
    fy = open("Y.txt")
    Y_raw = fy.readlines()
    Y = []
    for i in X_raw:
        X.append(i.strip().split(' '))
    for i in range(len(X)):
        for j in range(len(X[i])):
            X[i][j] = float(X[i][j])
    
    for i in Y_raw:
        Y.append(int(i.strip()))
    
    if add_x0 == True:
        for i in range(len(X)):
            X[i].append(1)

    X = np.array(X)
    Y = np.array(Y)
    return X, Y

## Be careful! Here you should change the absolute path in your own computer!
def save_data(train_err, train_acc, test_err, test_acc):

    f_train_err = open("train_err.txt", mode='w')
    for i in train_err:
        f_train_err.write(str(i))
        f_train_err.write('\n')
    f_train_acc = open("train_acc.txt", mode='w')
    for i in train_acc:
        f_train_acc.write(str(i))
        f_train_acc.write('\n')
    
    f_test_err = open("test_err.txt", mode='w')
    for i in test_err:
        f_test_err.write(str(i))
        f_test_err.write('\n')
    f_test_acc = open("test_acc.txt", mode='w')
    for i in test_acc:
        f_test_acc.write(str(i))
        f_test_acc.write('\n')



