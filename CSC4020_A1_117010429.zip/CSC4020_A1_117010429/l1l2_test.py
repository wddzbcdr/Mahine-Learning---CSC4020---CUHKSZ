import numpy as np
import random
import LogisticRegression as LR


def save_data(train_err, train_acc, test_err, test_acc):
    path = 'CSC4020_A1_117010429/outputdata/'
    f_train_err = open(path+"l1_0_0001_train_err.txt", mode='w')
    for i in train_err:
        f_train_err.write(str(i))
        f_train_err.write('\n')
    f_train_acc = open(path+"l1_0_0001_train_acc.txt", mode='w')
    for i in train_acc:
        f_train_acc.write(str(i))
        f_train_acc.write('\n')
    
    f_test_err = open(path+"l1_0_0001_test_err.txt", mode='w')
    for i in test_err:
        f_test_err.write(str(i))
        f_test_err.write('\n')
    f_test_acc = open(path+"l1_0_0001_test_acc.txt", mode='w')
    for i in test_acc:
        f_test_acc.write(str(i))
        f_test_acc.write('\n')

def main():
    X, Y = LR.read_data(add_x0=True)
    X = np.array(LR.normalization(X))
    split = int( 0.8 * len(Y) ) 
    part1X = X[:split]
    part1Y = Y[:split]
    part2X = X[split:]
    part2Y = Y[split:]
    

    model = LR.LogisticRegression(max_iter=3000)
    model.fit(part1X, part1Y, part2X, part2Y, reg='l1', ld=0.0001)
    save_data(model.train_error_list, model.train_accrancy_list, model.test_error_list, model.test_accrancy_list)

main()
