import numpy as np
import random
import LogisticRegression as LR



def main():
    X, Y = LR.read_data(add_x0=True)
    X = np.array(LR.normalization(X))
    model = LR.LogisticRegression(max_iter=3000)

    #General Test
    split1 = int( 0.8 * len(Y) )   
    X_train = X[:split1]
    X_test = X[split1:]
    Y_train = Y[:split1]
    Y_test = Y[split1:]
    model.fit(X_train, Y_train, X_test, Y_test, reg = None, ld = None)
    LR.save_data(model.train_error_list, model.train_accrancy_list, model.test_error_list, model.test_accrancy_list)

main()

